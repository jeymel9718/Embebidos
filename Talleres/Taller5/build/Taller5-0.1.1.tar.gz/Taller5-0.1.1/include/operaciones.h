#ifndef _OPERACIONES_H
#define _OPERACIONES_H

int add(int,int);
int sub(int,int);
int mul(int,int);
double div(int,int);
double sroot(int);

#endif
